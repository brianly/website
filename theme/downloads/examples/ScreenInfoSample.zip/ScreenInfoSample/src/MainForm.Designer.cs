﻿namespace MultipleMonitorInfo
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label4 = new System.Windows.Forms.Label();
            this.screenProperties = new System.Windows.Forms.ListView();
            this.columnHeaderProperty = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderValue = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.screenList = new System.Windows.Forms.ListBox();
            this.btnGetPrimaryInfo = new System.Windows.Forms.Button();
            this.btnGetCurrentScreenInfo = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(9, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(400, 13);
            this.label4.TabIndex = 9;
            this.label4.Text = "Select a screen from the list, or click a button. Try this sample with multiple m" +
                "onitors!";
            // 
            // screenProperties
            // 
            this.screenProperties.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeaderProperty,
            this.columnHeaderValue});
            this.screenProperties.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.screenProperties.Location = new System.Drawing.Point(12, 120);
            this.screenProperties.Name = "screenProperties";
            this.screenProperties.Size = new System.Drawing.Size(423, 169);
            this.screenProperties.TabIndex = 11;
            this.screenProperties.UseCompatibleStateImageBehavior = false;
            this.screenProperties.View = System.Windows.Forms.View.Details;
            // 
            // columnHeaderProperty
            // 
            this.columnHeaderProperty.Text = "Property";
            this.columnHeaderProperty.Width = 137;
            // 
            // columnHeaderValue
            // 
            this.columnHeaderValue.Text = "Value";
            this.columnHeaderValue.Width = 250;
            // 
            // screenList
            // 
            this.screenList.FormattingEnabled = true;
            this.screenList.Location = new System.Drawing.Point(12, 32);
            this.screenList.Name = "screenList";
            this.screenList.Size = new System.Drawing.Size(251, 82);
            this.screenList.TabIndex = 12;
            this.screenList.Click += new System.EventHandler(this.screenList_Click);
            // 
            // btnGetPrimaryInfo
            // 
            this.btnGetPrimaryInfo.Location = new System.Drawing.Point(269, 61);
            this.btnGetPrimaryInfo.Name = "btnGetPrimaryInfo";
            this.btnGetPrimaryInfo.Size = new System.Drawing.Size(166, 23);
            this.btnGetPrimaryInfo.TabIndex = 13;
            this.btnGetPrimaryInfo.Text = "Get Primary Screen Info";
            this.btnGetPrimaryInfo.UseVisualStyleBackColor = true;
            this.btnGetPrimaryInfo.Click += new System.EventHandler(this.btnGetPrimaryInfo_Click);
            // 
            // btnGetCurrentScreenInfo
            // 
            this.btnGetCurrentScreenInfo.Location = new System.Drawing.Point(269, 32);
            this.btnGetCurrentScreenInfo.Name = "btnGetCurrentScreenInfo";
            this.btnGetCurrentScreenInfo.Size = new System.Drawing.Size(166, 23);
            this.btnGetCurrentScreenInfo.TabIndex = 14;
            this.btnGetCurrentScreenInfo.Text = "Get Current Screen Info";
            this.btnGetCurrentScreenInfo.UseVisualStyleBackColor = true;
            this.btnGetCurrentScreenInfo.Click += new System.EventHandler(this.btnGetCurrentScreenInfo_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(269, 91);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(166, 23);
            this.btnClear.TabIndex = 15;
            this.btnClear.Text = "Clear Property List";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(450, 301);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnGetCurrentScreenInfo);
            this.Controls.Add(this.btnGetPrimaryInfo);
            this.Controls.Add(this.screenList);
            this.Controls.Add(this.screenProperties);
            this.Controls.Add(this.label4);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.Text = "Screen Info Sample";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ListView screenProperties;
        private System.Windows.Forms.ListBox screenList;
        private System.Windows.Forms.ColumnHeader columnHeaderProperty;
        private System.Windows.Forms.ColumnHeader columnHeaderValue;
        private System.Windows.Forms.Button btnGetPrimaryInfo;
        private System.Windows.Forms.Button btnGetCurrentScreenInfo;
        private System.Windows.Forms.Button btnClear;
    }
}

