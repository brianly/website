﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ElmahIntegration
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            int result = Divide(5, 0);
        }

        private int Divide(int op1, int op2)
        {
            return op1 / op2;
        }
    }
}
