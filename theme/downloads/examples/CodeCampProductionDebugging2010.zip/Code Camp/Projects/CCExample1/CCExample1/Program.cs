﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;

namespace CCExample1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Super calculator! v1");

            // Pops this method onto the stack to match
            // the slides which mention debug/release build
            RunCode();

            Console.WriteLine("Hit the any key");
            Console.ReadKey();
        }


        private static void RunCode()
        {
            const int op1 = 10;
            const int op2 = 3;
            const int zero = 0;

            // Addition
            int addition = Add(op1, op2);
            Output(string.Format("Result of addition: {0}", addition));

            // Division
            int division = Divide(op1, op2);
            Output(string.Format("Result of {2} divided by {1}: {0}", division, op2, op1));

            // Buggy - simple mistake
            int badDivision = Divide(op1, zero);

            // Less buggy!
            //try
            //{
            //    int badDivision = SafeDivide(op1, zero);
            //    Output(string.Format("Result of buggy division method: {0}", badDivision));
            //}
            //catch (DivideByZeroException e)
            //{
            //    Console.WriteLine(e.Message);
            //}
        }

        // Alternative
        //private static int SafeDivide(int op1, int op2)
        //{
        //    int result = 0;

        //    if (op2 == 0)
        //    {
        //        throw new ArgumentException("You cannot divide by zero");
        //    }

        //    result = Divide(op1, op2);

        //    return result;
        //}

        // Original implementation
        private static int SafeDivide(int op1, int op2)
        {
            int result = 0;

            if (op2 != 0)
            {
                result = Divide(op1, op2);
            }

            return result;
        }

        private static int Add(int op1, int op2)
        {
            return op1 + op2;
        }

        private static int Divide(int op1, int op2)
        {
            return op1 / op2;
        }

        private static void Output(string output)
        {
            Debug.WriteLine(output);
            Console.WriteLine(output);
        }
    }
}
