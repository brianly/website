﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WebServiceExampleClient
{
    class Program
    {
        static void Main(string[] args)
        {
            TestService.Service1 svc = new TestService.Service1();
            int result = svc.Divide(10, 0);

            Console.WriteLine("Result: {0}", result);
            Console.ReadKey();
        }
    }
}
